// 05. Consultas de agregación: contar, sumar y promediar
use("bigdata");

// Contar todos los documentos (resultado obtenido: 8975)
db.datos.aggregate([
  { $count: "totalEstaciones" }
]);

// Contar por estado (Activa 5491, Suspendida 3439, En Mantenimiento 43, Inactiva 2)
db.datos.aggregate([
  { $group: { _id: "$Estado", total: { $sum: 1 } } }
]);

// Promedio de un campo numérico
db.datos.aggregate([
  { $group: { _id: null, promedioCodigo: { $avg: "$Codigo" } } }
]);

// Suma de un campo numérico
db.datos.aggregate([
  { $group: { _id: null, sumaCodigo: { $sum: "$Codigo" } } }
]);

// Estadísticas de altitud por departamento (estaciones activas)
db.datos.aggregate([
  { $match: { Estado: "Activa", Altitud: { $type: "number" } } },
  { $group: {
      _id: "$Departamento",
      totalEstaciones: { $sum: 1 },
      altitudPromedio: { $avg: "$Altitud" },
      altitudMinima: { $min: "$Altitud" },
      altitudMaxima: { $max: "$Altitud" }
  } },
  { $sort: { totalEstaciones: -1 } },
  { $limit: 10 }
]);

// Estaciones por categoría
db.datos.aggregate([
  { $group: { _id: "$Categoria", total: { $sum: 1 } } },
  { $sort: { total: -1 } }
]);
