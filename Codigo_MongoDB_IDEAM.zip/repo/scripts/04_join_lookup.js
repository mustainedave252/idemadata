// 04. Unión entre colecciones ($lookup, equivalente al JOIN de SQL)
use("bigdata");

// Colección de apoyo con la región natural de cada departamento
db.departamentos.drop();
db.departamentos.insertMany([
  { Departamento: "Amazonas", Region: "Amazonía", Capital: "Leticia" },
  { Departamento: "Antioquia", Region: "Andina", Capital: "Medellín" },
  { Departamento: "Arauca", Region: "Orinoquía", Capital: "Arauca" },
  { Departamento: "Archipiélago de San Andrés, Providencia y Santa Catalina", Region: "Insular", Capital: "San Andrés" },
  { Departamento: "Atlántico", Region: "Caribe", Capital: "Barranquilla" },
  { Departamento: "Bogotá", Region: "Andina", Capital: "Bogotá" },
  { Departamento: "Bolívar", Region: "Caribe", Capital: "Cartagena" },
  { Departamento: "Boyacá", Region: "Andina", Capital: "Tunja" },
  { Departamento: "Caldas", Region: "Andina", Capital: "Manizales" },
  { Departamento: "Caquetá", Region: "Amazonía", Capital: "Florencia" },
  { Departamento: "Casanare", Region: "Orinoquía", Capital: "Yopal" },
  { Departamento: "Cauca", Region: "Pacífica", Capital: "Popayán" },
  { Departamento: "Cesar", Region: "Caribe", Capital: "Valledupar" },
  { Departamento: "Chocó", Region: "Pacífica", Capital: "Quibdó" },
  { Departamento: "Córdoba", Region: "Caribe", Capital: "Montería" },
  { Departamento: "Cundinamarca", Region: "Andina", Capital: "Bogotá" },
  { Departamento: "Guainía", Region: "Amazonía", Capital: "Inírida" },
  { Departamento: "Guaviare", Region: "Amazonía", Capital: "San José del Guaviare" },
  { Departamento: "Huila", Region: "Andina", Capital: "Neiva" },
  { Departamento: "La Guajira", Region: "Caribe", Capital: "Riohacha" },
  { Departamento: "Magdalena", Region: "Caribe", Capital: "Santa Marta" },
  { Departamento: "Meta", Region: "Orinoquía", Capital: "Villavicencio" },
  { Departamento: "Nariño", Region: "Pacífica", Capital: "Pasto" },
  { Departamento: "Norte de Santander", Region: "Andina", Capital: "Cúcuta" },
  { Departamento: "Putumayo", Region: "Amazonía", Capital: "Mocoa" },
  { Departamento: "Quindío", Region: "Andina", Capital: "Armenia" },
  { Departamento: "Risaralda", Region: "Andina", Capital: "Pereira" },
  { Departamento: "Santander", Region: "Andina", Capital: "Bucaramanga" },
  { Departamento: "Sucre", Region: "Caribe", Capital: "Sincelejo" },
  { Departamento: "Tolima", Region: "Andina", Capital: "Ibagué" },
  { Departamento: "Valle del Cauca", Region: "Pacífica", Capital: "Cali" },
  { Departamento: "Vaupés", Region: "Amazonía", Capital: "Mitú" },
  { Departamento: "Vichada", Region: "Orinoquía", Capital: "Puerto Carreño" }
]);
// Nota: revise que los nombres coincidan exactamente con el campo Departamento del CSV
// (tildes, "Bogotá D.C.", "San Andrés", etc.). Para ver los valores distintos:
//   db.datos.distinct("Departamento")

// Estaciones activas por región natural
db.datos.aggregate([
  { $match: { Estado: "Activa" } },
  { $lookup: {
      from: "departamentos",
      localField: "Departamento",
      foreignField: "Departamento",
      as: "infoDepto"
  } },
  { $unwind: "$infoDepto" },
  { $group: { _id: "$infoDepto.Region", estacionesActivas: { $sum: 1 } } },
  { $sort: { estacionesActivas: -1 } }
]);
