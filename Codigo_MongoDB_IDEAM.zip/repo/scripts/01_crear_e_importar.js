// 01. Creación de la base de datos e importación
// La importación del CSV se hizo desde MongoDB Compass (Add Data > Import JSON or CSV)
// hacia la colección bigdata.datos. Alternativa por consola:
//   mongoimport --db bigdata --collection datos --type csv --headerline --file Catalogo_Estaciones_IDEAM.csv
// Ejecutar este script con: mongosh scripts/01_crear_e_importar.js

use("bigdata");

// Verificar el número de documentos importados (resultado obtenido: 8973)
print("Documentos en datos:", db.datos.countDocuments());

// Índices recomendados por el diseño del esquema
db.datos.createIndex({ Codigo: 1 }, { unique: true });
db.datos.createIndex({ Departamento: 1, Estado: 1 });
