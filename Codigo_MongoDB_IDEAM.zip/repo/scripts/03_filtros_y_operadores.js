// 03. Consultas con filtros y operadores
use("bigdata");

// Filtro simple
db.datos.find({ "Estado": "Activa" });

// Varias condiciones (AND implícito)
db.datos.find({
  "Estado": "Activa",
  "Departamento": "Santander"
});

// Operador lógico $or
db.datos.find({
  $or: [
    { "Estado": "Activa" },
    { "Departamento": "Cauca" }
  ]
});

// Operadores de comparación $in y $gt con proyección y orden
db.datos.find(
  { Estado: "Activa", Departamento: { $in: ["Nariño", "Cauca"] }, Altitud: { $gt: 3000 } },
  { _id: 0, Codigo: 1, Nombre: 1, Municipio: 1, Altitud: 1 }
).sort({ Altitud: -1 });
