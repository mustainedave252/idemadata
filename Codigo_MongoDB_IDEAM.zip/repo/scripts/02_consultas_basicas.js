// 02. Consultas básicas: inserción, selección, actualización y eliminación
use("bigdata");

// ---------- Inserción de un documento ----------
db.datos.insertOne({
  "Codigo": 52057200,
  "Nombre": "Estación Ejemplo",
  "Categoria": "Meteorológica",
  "Estado": "Activa",
  "Departamento": "Cauca",
  "Municipio": "Popayán",
  "Corriente": "Cauca"
});

// ---------- Inserción de varios documentos ----------
db.datos.insertMany([
  {
    "Codigo": 52057300,
    "Nombre": "Estación 2",
    "Categoria": "Limnigráfica",
    "Estado": "Activa",
    "Departamento": "Nariño",
    "Municipio": "Ipiales",
    "Corriente": "Guaitara"
  },
  {
    "Codigo": 52057400,
    "Nombre": "Estación 3",
    "Categoria": "Meteorológica",
    "Estado": "Inactiva",
    "Departamento": "Cauca",
    "Municipio": "Popayán",
    "Corriente": "Cauca"
  }
]);

// ---------- Selección ----------
db.datos.find();                       // todos los documentos
db.datos.find().limit(5);              // solo los primeros cinco
db.datos.find({}, { "Codigo": 1, "Nombre": 1, "_id": 0 }).limit(5); // proyección

// ---------- Actualización ----------
db.datos.updateOne(
  { "Codigo": 52057200 },
  { $set: { "Estado": "Inactiva" } }
);

// ---------- Eliminación ----------
db.datos.deleteOne({ "Codigo": 52057300 });
