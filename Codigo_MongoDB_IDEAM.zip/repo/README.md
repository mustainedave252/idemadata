# MongoDB: Catálogo Nacional de Estaciones del IDEAM

Trabajo de la Fase 2 del curso Big Data (UNAD). Se diseñó e implementó una base de datos documental en MongoDB con el Catálogo Nacional de Estaciones del IDEAM (8.973 estaciones hidrológicas y meteorológicas de Colombia).

## Estructura

| Archivo | Contenido |
|---|---|
| `scripts/01_crear_e_importar.js` | Base `bigdata`, verificación de la importación e índices |
| `scripts/02_consultas_basicas.js` | insertOne, insertMany, find, limit, proyección, updateOne, deleteOne |
| `scripts/03_filtros_y_operadores.js` | Filtros simples, AND implícito, `$or`, `$in`, `$gt` |
| `scripts/04_join_lookup.js` | Colección `departamentos` y unión con `$lookup` |
| `scripts/05_agregaciones.js` | `$count`, `$group`, `$sum`, `$avg`, `$min`, `$max` |

## Esquema

Base de datos `bigdata`, colección `datos` (un documento por estación):

```json
{
  "Codigo": 52057100,
  "Nombre": "RUMICHACA - AUT [52057100]",
  "Categoria": "Limnigráfica",
  "Estado": "Activa",
  "Departamento": "Nariño",
  "Municipio": "Ipiales",
  "Ubicación": "(0.81378611, -77.66197778)",
  "Altitud": 2582,
  "Fecha_instalacion": "2016-11-15T00:00:00Z",
  "Corriente": "Guaitara"
}
```

Colección de apoyo `departamentos`: `{ Departamento, Region, Capital }`.

## Cómo ejecutar

1. Descargar el Catálogo Nacional de Estaciones desde DHIME (http://dhime.ideam.gov.co/atencionciudadano/, sección Recursos) y guardarlo como CSV.
2. Importarlo en la colección `bigdata.datos` con MongoDB Compass o con:
   ```
   mongoimport --db bigdata --collection datos --type csv --headerline --file Catalogo_Estaciones_IDEAM.csv
   ```
3. Ejecutar los scripts en orden con `mongosh scripts/01_crear_e_importar.js`, o copiarlos en la consola de mongosh dentro de Compass.

## Fuente de datos

Instituto de Hidrología, Meteorología y Estudios Ambientales (IDEAM). Catálogo Nacional de Estaciones. DHIME.
